git pull
git submodule update
git submodule foreach git pull origin master
git add extra pkg exe
git commit -m "updating packages"
