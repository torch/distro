require 'torch'

gnuplot = {}
include('gnuplot.lua')
include('hist.lua')

return gnuplot
